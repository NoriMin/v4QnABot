﻿// Licensed under the MIT License.

using System;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;


namespace EchoBot.Models
{
    public class CustomQnAMaker
    {
        /* 以下の3種類のキーを入力してください */

        private const string KnowledgebaseId = "YOUR_KBID";
        private const string Host = "YOUR_HOST_NAME";
        private const string EndpointKey = "YOUR_ENDPOINTKEY";

        private const string RequestUri = Host + "/knowledgebases/" + KnowledgebaseId + "/generateAnswer/";
        public static async Task<string> GetResults(string message)
        {
            var question = $"{{\"question\": \"{message}\", \"top\": 5}}";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage())
                {
                    request.Method = HttpMethod.Post;
                    request.RequestUri = new Uri(RequestUri);
                    request.Content = new StringContent(question, Encoding.UTF8, "application/json");
                    request.Headers.Add("Authorization", "EndpointKey " + EndpointKey);

                    using (var response = await client.SendAsync(request))
                    {
                        if(response.IsSuccessStatusCode)
                        {
                            string json = await response.Content.ReadAsStringAsync();
                            return json;
                        }

                        string failure = "failure";
                        return failure;
                    }

                }
            }

        }
    }
}
